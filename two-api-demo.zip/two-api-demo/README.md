# Two-API Demo (API1 -> API2) with Docker Compose on Windows

## Run
1. Install Docker Desktop (Linux containers, WSL2 backend).
2. Clone repo and open PowerShell in project root.
3. Build & run:
   ```powershell
   docker compose up --build -d
